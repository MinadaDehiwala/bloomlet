import React from 'react';
import { FaUser, FaLock, FaEnvelope, FaChild } from 'react-icons/fa';
import { motion } from 'framer-motion';

const Signup = () => {
  return (
    <div className="bg-gray-100 min-h-screen flex flex-col items-center">
      <div className="topnav bg-blue-600 w-full flex justify-around p-4 shadow-lg rounded-b-lg">
        <a className="text-white text-center text-lg hover:text-gray-200 transition duration-200" href="/">LOGO</a>
        <a className="text-white text-center text-lg hover:text-gray-200 transition duration-200" href="/">Home</a>
        <a className="text-white text-center text-lg hover:text-gray-200 transition duration-200" href="/userdashboard">Progress</a>
        <a className="text-white text-center text-lg hover:text-gray-200 transition duration-200" href="/login">Login</a>
      </div>

      <div className="bg-gray-100 min-h-screen flex items-center justify-center">
        <motion.div 
          className="bg-white p-10 rounded-lg shadow-lg w-full max-w-3xl !important"  // Added !important
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-4xl font-bold mb-6 text-center text-blue-600">Sign Up</h1>
          <form>
            <div className="mb-4">
              <label htmlFor="name" className="block text-gray-700 text-sm font-bold mb-2">Name</label>
              <div className="flex items-center border border-gray-300 rounded-lg">
                <FaUser className="text-gray-400 mx-3" />
                <input 
                  type="text" 
                  id="name" 
                  placeholder="Name" 
                  className="w-full p-3 focus:outline-none focus:ring-2 focus:ring-blue-500 rounded-r-lg bg-white"
                />
              </div>
            </div>
            <div className="mb-4">
              <label htmlFor="age" className="block text-gray-700 text-sm font-bold mb-2">Age of Child</label>
              <div className="flex items-center border border-gray-300 rounded-lg">
                <FaChild className="text-gray-400 mx-3" />
                <input 
                  type="number" 
                  id="age" 
                  placeholder="Age of Child" 
                  className="w-full p-3 focus:outline-none focus:ring-2 focus:ring-blue-500 rounded-r-lg bg-white"
                />
              </div>
            </div>
            <div className="mb-4">
              <label htmlFor="email" className="block text-gray-700 text-sm font-bold mb-2">Email</label>
              <div className="flex items-center border border-gray-300 rounded-lg">
                <FaEnvelope className="text-gray-400 mx-3" />
                <input 
                  type="email" 
                  id="email" 
                  placeholder="Email" 
                  className="w-full p-3 focus:outline-none focus:ring-2 focus:ring-blue-500 rounded-r-lg bg-white"
                />
              </div>
            </div>
            <div className="mb-4">
              <label htmlFor="screenTime" className="block text-gray-700 text-sm font-bold mb-2">Child Screen Time</label>
              <div className="flex items-center border border-gray-300 rounded-lg">
                <FaChild className="text-gray-400 mx-3" />
                <input 
                  type="number" 
                  id="screenTime" 
                  placeholder="Child Screen Time" 
                  className="w-full p-3 focus:outline-none focus:ring-2 focus:ring-blue-500 rounded-r-lg bg-white"
                />
              </div>
            </div>
            <div className="mb-4">
              <label htmlFor="password" className="block text-gray-700 text-sm font-bold mb-2">Password</label>
              <div className="flex items-center border border-gray-300 rounded-lg">
                <FaLock className="text-gray-400 mx-3" />
                <input 
                  type="password" 
                  id="password" 
                  placeholder="Password" 
                  className="w-full p-3 focus:outline-none focus:ring-2 focus:ring-blue-500 rounded-r-lg bg-white"
                />
              </div>
            </div>
            <div className="mb-6">
              <label htmlFor="confirmPassword" className="block text-gray-700 text-sm font-bold mb-2">Confirm Password</label>
              <div className="flex items-center border border-gray-300 rounded-lg">
                <FaLock className="text-gray-400 mx-3" />
                <input 
                  type="password" 
                  id="confirmPassword" 
                  placeholder="Confirm Password" 
                  className="w-full p-3 focus:outline-none focus:ring-2 focus:ring-blue-500 rounded-r-lg bg-white"
                />
              </div>
            </div>
            <button 
              type="submit" 
              className="w-full bg-blue-600 text-white py-3 rounded-lg font-bold hover:bg-blue-700 transition duration-200"
            >
              Sign Up
            </button>
          </form>
        </motion.div>
      </div>
    </div>
  );
};

export default Signup;
